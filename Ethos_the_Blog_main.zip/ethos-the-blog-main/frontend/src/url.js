export const URL = "http://localhost:5000";
export const IF = "http://localhost:5000/images/";
